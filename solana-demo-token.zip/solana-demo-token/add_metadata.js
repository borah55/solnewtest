import {
  Connection,
  clusterApiUrl,
  Keypair,
  PublicKey
} from "@solana/web3.js";
import {
  bundlrStorage,
  Metaplex,
  keypairIdentity,
  toMetaplexFile
} from "@metaplex-foundation/js";
import fs from "fs";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
const wallet = Keypair.fromSecretKey(
  Uint8Array.from(JSON.parse(fs.readFileSync(`${process.env.HOME}/.config/solana/id.json`)))
);

const metaplex = Metaplex.make(connection)
  .use(keypairIdentity(wallet))
  .use(bundlrStorage());

const main = async () => {
  const mintAddress = new PublicKey("PASTE_YOUR_MINT_ADDRESS_HERE"); // Replace

  const imageBuffer = fs.readFileSync("token-logo.png");
  const file = toMetaplexFile(imageBuffer, "token-logo.png");
  const imageUri = await metaplex.storage().upload(file);

  const { uri } = await metaplex.nfts().uploadMetadata({
    name: "Demo Token",
    symbol: "DEMO",
    description: "A demo token for testing on Solana devnet",
    image: imageUri,
  });

  const { nft } = await metaplex.nfts().create({
    uri,
    name: "Demo Token",
    symbol: "DEMO",
    sellerFeeBasisPoints: 0,
    mintAddress: mintAddress,
  });

  console.log("✅ Metadata created! Address:", nft.address.toBase58());
};

main().catch(console.error);
