import {
  Connection,
  clusterApiUrl,
  Keypair,
  LAMPORTS_PER_SOL,
} from "@solana/web3.js";
import {
  createMint,
  getOrCreateAssociatedTokenAccount,
  mintTo,
} from "@solana/spl-token";
import fs from "fs";

const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
const wallet = Keypair.fromSecretKey(
  Uint8Array.from(JSON.parse(fs.readFileSync(`${process.env.HOME}/.config/solana/id.json`)))
);

const main = async () => {
  const airdropSig = await connection.requestAirdrop(wallet.publicKey, LAMPORTS_PER_SOL);
  await connection.confirmTransaction(airdropSig);

  const mint = await createMint(connection, wallet, wallet.publicKey, null, 9);
  const tokenAccount = await getOrCreateAssociatedTokenAccount(
    connection, wallet, mint, wallet.publicKey
  );

  await mintTo(connection, wallet, mint, tokenAccount.address, wallet, 1000n * 10n ** 9n);

  console.log("✅ Token Mint Address:", mint.toBase58());
};

main().catch(console.error);
